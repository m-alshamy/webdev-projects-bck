const SUPABASE_URL = 'https://whiiadjocmkppzfpbkeh.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoaWlhZGpvY21rcHB6ZnBia2VoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkzOTk1NzQsImV4cCI6MjEwNDk3NTU3NH0.1IipeBlRqwehixssS-xCDTP0JB8Fj5ajBuKE8AVKlqA';

document.addEventListener("DOMContentLoaded", async () => {
    const statusTitle = document.getElementById('statusTitle');
    const statusDesc = document.getElementById('statusDesc');

    const params = new URLSearchParams(window.location.search);
    const txId = params.get('tx');

    statusDesc.textContent = "";
    if (!txId) {
        statusTitle.textContent = "عملية غير صالحة";
        statusTitle.classList.add("text-red-400");
        statusDesc.textContent = "لم يتم العثور على معرف عملية في الرابط.";
        return;
    }

    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
    const { data: { session } } = await supabaseClient.auth.getSession();

    if (!session) {
        statusTitle.textContent = "يجب تسجيل الدخول";
        statusTitle.classList.add("text-red-400");
        statusDesc.textContent = "الرجاء تسجيل الدخول للتحقق من حالة العملية.";
        return;
    }

    // السيرفر هو من يقرر النتيجة الحقيقية عبر سؤال بوابة الدفع مباشرة،
    // ولا نعتمد إطلاقًا على أي بيانات محفوظة في المتصفح.
    try {
        const url = `/check-transaction?tx=${encodeURIComponent(txId)}&access_token=${encodeURIComponent(session.access_token)}`;
        const response = await fetch(url);
        const data = await response.json();

        if (data.status === "completed") {
            statusTitle.textContent = "تمت عملية الشحن بنجاح!";
            statusTitle.classList.add("text-green-400");
            statusDesc.textContent = `رصيدك الحالي: ${data.balance} ج.م`;
        } else if (data.status === "pending") {
            statusTitle.textContent = "العملية قيد المعالجة";
            statusTitle.classList.add("text-yellow-400");
            statusDesc.textContent = "الرجاء الانتظار قليلاً ثم تحديث الصفحة.";
        } else {
            statusTitle.textContent = "فشلت عملية الدفع";
            statusTitle.classList.add("text-red-400");
            statusDesc.textContent = data.error || "لم يتم تأكيد الدفع من البوابة.";
        }
    } catch (e) {
        statusTitle.textContent = "تعذر التحقق";
        statusTitle.classList.add("text-red-400");
        statusDesc.textContent = "فشل الاتصال بالخادم المحلي.";
    }
});