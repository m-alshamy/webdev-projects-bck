import json
import urllib.request
from http.server import SimpleHTTPRequestHandler, HTTPServer

class PaymentHandler(SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/create-payment':
            url = "https://secure-egypt.paytabs.com/payment/request"
            # استبدل هذه القيم ببيانات حسابك التجريبي
            server_key = "SKJ9WLTK22-J99BBK6TGW-TJGM2GHRJZ"
            payload = {
                "profile_id": "154718",
                "tran_type": "sale",
                "tran_class": "ecom",
                "cart_id": "course_001",
                "cart_description": "شراء كورس",
                "cart_currency": "EGP",
                "cart_amount": 150,
                "hide_shipping": True,
                "return": "http://192.168.1.13:4444/success",
                "customer_details": {
                    "name": "Customer Name",
                    "email": "any@example.com",
                    "phone": "01000000000",
                    "street1": "404, 11th st, void",
                    "city": "Cairo",
                    "state": "Cairo",
                    "country": "EG",
                    "ip": "127.0.0.1"
                }
            }
            
            req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'))
            req.add_header('Authorization', server_key)
            req.add_header('Content-Type', 'application/json')
            
            try:
                response = urllib.request.urlopen(req)
                response_data = response.read()
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(response_data)
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write('{"error": "Cannot connect the portal !}')
        else:
            # تجاهل أي طلبات POST أخرى
            self.send_error(404, "Not Found")

print("الخادم يعمل على الرابط: http://192.168.1.13:4444")
HTTPServer(('0.0.0.0', 4444), PaymentHandler).serve_forever()