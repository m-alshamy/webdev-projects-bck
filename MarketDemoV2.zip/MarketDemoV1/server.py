import json
import os
import uuid
import urllib.request
import urllib.error
from urllib.parse import urlparse, parse_qs
from http.server import SimpleHTTPRequestHandler, HTTPServer

# ============================================================
# إعدادات Supabase
# ============================================================
SUPABASE_URL = "https://whiiadjocmkppzfpbkeh.supabase.co"

# مفتاح anon: نفس المفتاح العام الموجود في الواجهة، يُستخدم فقط
# للتحقق من صلاحية الجلسة (access_token) وليس للكتابة في قاعدة البيانات.
SUPABASE_ANON_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind"
    "oaWlhZGpvY21rcHB6ZnBia2VoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkzOTk1NzQsIm"
    "V4cCI6MjEwNDk3NTU3NH0.1IipeBlRqwehixssS-xCDTP0JB8Fj5ajBuKE8AVKlqA"
)

# مفتاح service_role: سرّي بالكامل ولا يوضع أبدًا في أي ملف يصل للمتصفح.
# ضعه كمتغير بيئة قبل تشغيل السيرفر:
#   export SUPABASE_SERVICE_ROLE_KEY="القيمة من Supabase > Project Settings > API"
SUPABASE_SERVICE_KEY = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoaWlhZGpvY21rcHB6ZnBia2VoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4OTM5OTU3NCwiZXhwIjoyMTA0OTc1NTc0fQ.jafAuagX8C6xA9-10M5iJXgxtZ3adpjFfxduvd8FpRU")

# ============================================================
# إعدادات PayTabs
# ============================================================
PAYTABS_CREATE_URL = "https://secure-egypt.paytabs.com/payment/request"
PAYTABS_QUERY_URL = "https://secure-egypt.paytabs.com/payment/query"
PAYTABS_PROFILE_ID = "154718"
PAYTABS_SERVER_KEY = "SKJ9WLTK22-J99BBK6TGW-TJGM2GHRJZ"

HOST_URL = "http://192.168.1.13:4444"

MIN_AMOUNT = 1
MAX_AMOUNT = 5000  # سقف بسيط لمنع إدخال قيم غير منطقية


# ============================================================
# أدوات مساعدة: Supabase
# ============================================================
def supabase_get_user(access_token):
    """يتحقق من صلاحية الجلسة مع Supabase ويرجع بيانات المستخدم الحقيقية (id, email)."""
    req = urllib.request.Request(f"{SUPABASE_URL}/auth/v1/user")
    req.add_header("apikey", SUPABASE_ANON_KEY)
    req.add_header("Authorization", f"Bearer {access_token}")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def supabase_service_request(method, path, body=None):
    """طلب إلى Supabase REST/RPC باستخدام مفتاح service_role (صلاحيات كاملة، يُستخدم من السيرفر فقط)."""
    if not SUPABASE_SERVICE_KEY:
        raise RuntimeError("SUPABASE_SERVICE_ROLE_KEY غير مضبوط كمتغير بيئة")

    url = f"{SUPABASE_URL}{path}"
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("apikey", SUPABASE_SERVICE_KEY)
    req.add_header("Authorization", f"Bearer {SUPABASE_SERVICE_KEY}")
    req.add_header("Content-Type", "application/json")
    req.add_header("Prefer", "return=representation")
    with urllib.request.urlopen(req, timeout=10) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else None


# ============================================================
# أدوات مساعدة: PayTabs
# ============================================================
def paytabs_create_payment(tran_id, amount, customer_email, customer_name, customer_phone):
    payload = {
        "profile_id": PAYTABS_PROFILE_ID,
        "tran_type": "sale",
        "tran_class": "ecom",
        "cart_id": tran_id,
        "cart_description": "شحن محفظة",
        "cart_currency": "EGP",
        "cart_amount": amount,
        "hide_shipping": True,
        "return": f"{HOST_URL}/success?tx={tran_id}",
        "customer_details": {
            "name": customer_name or "عميل",
            "email": customer_email,
            "phone": customer_phone or "",
            "street1": "N/A",
            "city": "Cairo",
            "state": "Cairo",
            "country": "EG",
            "ip": "127.0.0.1",
        },
    }
    req = urllib.request.Request(
        PAYTABS_CREATE_URL, data=json.dumps(payload).encode("utf-8")
    )
    req.add_header("Authorization", PAYTABS_SERVER_KEY)
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


def paytabs_query_transaction(tran_ref):
    """يسأل PayTabs مباشرة (سيرفر لسيرفر) عن الحالة الحقيقية للعملية - لا يعتمد على أي شيء يرسله المتصفح."""
    payload = {"profile_id": PAYTABS_PROFILE_ID, "tran_ref": tran_ref}
    req = urllib.request.Request(
        PAYTABS_QUERY_URL, data=json.dumps(payload).encode("utf-8")
    )
    req.add_header("Authorization", PAYTABS_SERVER_KEY)
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


class PaymentHandler(SimpleHTTPRequestHandler):
    # --------------------------------------------------------
    def _send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            return {}

    # --------------------------------------------------------
    def do_POST(self):
        if self.path == "/create-payment":
            return self._handle_create_payment()
        self.send_error(404, "Not Found")

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/check-transaction":
            return self._handle_check_transaction(parse_qs(parsed.query))
        # أي مسار آخر: تصرف كخادم ملفات ثابت كما كان
        return super().do_GET()

    # --------------------------------------------------------
    def _handle_create_payment(self):
        body = self._read_json_body()
        access_token = body.get("access_token")
        amount = body.get("amount")

        if not access_token:
            return self._send_json(401, {"error": "يجب تسجيل الدخول"})

        # 1) تحقق من هوية المستخدم عبر Supabase - لا نثق بأي بيانات هوية من العميل
        user = supabase_get_user(access_token)
        if not user or "id" not in user:
            return self._send_json(401, {"error": "الجلسة غير صالحة"})

        user_id = user["id"]
        email = user.get("email", "")

        # 2) تحقق من صحة المبلغ
        try:
            amount = float(amount)
        except (TypeError, ValueError):
            return self._send_json(400, {"error": "مبلغ غير صالح"})
        if not (MIN_AMOUNT <= amount <= MAX_AMOUNT):
            return self._send_json(400, {"error": "المبلغ خارج الحد المسموح"})

        # 3) اجلب بيانات المستخدم الإضافية من قاعدة البيانات (وليس من العميل)
        try:
            rows = supabase_service_request(
                "GET",
                f"/rest/v1/user_data?id=eq.{user_id}&select=username,phone",
            )
            profile = rows[0] if rows else {}
        except Exception:
            profile = {}

        # 4) أنشئ سجل عملية معلّقة (pending) قبل التوجه لبوابة الدفع
        try:
            tran_rows = supabase_service_request(
                "POST",
                "/rest/v1/transactions",
                body={"user_id": user_id, "amount": amount, "status": "pending"},
            )
            tran_id = tran_rows[0]["id"]
        except Exception as e:
            return self._send_json(500, {"error": f"تعذر إنشاء العملية: {e}"})

        # 5) أنشئ عملية الدفع في PayTabs بحمولة ديناميكية حقيقية
        try:
            pt_response = paytabs_create_payment(
                tran_id, amount, email, profile.get("username"), profile.get("phone")
            )
        except Exception as e:
            return self._send_json(502, {"error": f"تعذر الاتصال بالبوابة: {e}"})

        tran_ref = pt_response.get("tran_ref")
        if tran_ref:
            try:
                supabase_service_request(
                    "PATCH",
                    f"/rest/v1/transactions?id=eq.{tran_id}",
                    body={"tran_ref": tran_ref},
                )
            except Exception:
                pass  # سيتم التحقق لاحقًا عبر cart_id عند الحاجة

        redirect_url = pt_response.get("redirect_url")
        if not redirect_url:
            return self._send_json(
                502, {"error": pt_response.get("message", "رفضت البوابة إنشاء العملية")}
            )

        return self._send_json(200, {"redirect_url": redirect_url})

    # --------------------------------------------------------
    def _handle_check_transaction(self, query):
        access_token = (query.get("access_token") or [None])[0]
        tx_id = (query.get("tx") or [None])[0]

        if not access_token or not tx_id:
            return self._send_json(400, {"error": "بيانات ناقصة"})

        user = supabase_get_user(access_token)
        if not user or "id" not in user:
            return self._send_json(401, {"error": "الجلسة غير صالحة"})
        user_id = user["id"]

        # اجلب سجل العملية وتأكد أنها تخص هذا المستخدم فعلاً (وليس مستخدمًا آخر)
        try:
            rows = supabase_service_request(
                "GET",
                f"/rest/v1/transactions?id=eq.{tx_id}&user_id=eq.{user_id}&select=*",
            )
        except Exception as e:
            return self._send_json(500, {"error": str(e)})

        if not rows:
            return self._send_json(404, {"error": "العملية غير موجودة"})
        tran = rows[0]

        if tran["status"] == "completed":
            balance = self._get_balance(user_id)
            return self._send_json(200, {"status": "completed", "balance": balance})

        if not tran.get("tran_ref"):
            return self._send_json(200, {"status": "pending"})

        # اسأل PayTabs نفسها (سيرفر لسيرفر) عن الحالة الحقيقية - هذا هو مصدر الثقة الوحيد
        try:
            pt_status = paytabs_query_transaction(tran["tran_ref"])
        except Exception as e:
            return self._send_json(502, {"error": f"تعذر التحقق من البوابة: {e}"})

        if pt_status.get("payment_result", {}).get("response_status") == "A":
            # نجاح مؤكد من البوابة نفسها -> اعتمد الرصيد عبر دالة SQL ذرية (تمنع الشحن المزدوج)
            try:
                supabase_service_request(
                    "POST",
                    "/rest/v1/rpc/credit_wallet",
                    body={
                        "p_user_id": user_id,
                        "p_transaction_id": tx_id,
                        "p_amount": tran["amount"],
                    },
                )
            except Exception as e:
                return self._send_json(500, {"error": f"تعذر اعتماد الرصيد: {e}"})

            balance = self._get_balance(user_id)
            return self._send_json(200, {"status": "completed", "balance": balance})

        return self._send_json(200, {"status": "failed"})

    def _get_balance(self, user_id):
        try:
            rows = supabase_service_request(
                "GET", f"/rest/v1/wallet?user_id=eq.{user_id}&select=balance"
            )
            return rows[0]["balance"] if rows else 0
        except Exception:
            return None


if __name__ == "__main__":
    if not SUPABASE_SERVICE_KEY:
        print("تحذير: SUPABASE_SERVICE_ROLE_KEY غير مضبوط - عمليات المحفظة لن تعمل")
    print(f"الخادم يعمل على الرابط: {HOST_URL}")
    HTTPServer(("0.0.0.0", 4444), PaymentHandler).serve_forever()