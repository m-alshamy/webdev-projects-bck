const SUPABASE_URL = 'https://whiiadjocmkppzfpbkeh.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoaWlhZGpvY21rcHB6ZnBia2VoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkzOTk1NzQsImV4cCI6MjEwNDk3NTU3NH0.1IipeBlRqwehixssS-xCDTP0JB8Fj5ajBuKE8AVKlqA';

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const userEmailSpan = document.getElementById('user-email');
const userExtraDataSpan = document.getElementById('user-extra-data');

// التحقق من الجلسة عند تحميل الصفحة
async function checkSession() {
    const { data: { user }, error } = await supabaseClient.auth.getUser();

    if (error || !user) {
        window.location.href = '/';
        return;
    }

    userEmailSpan.textContent = user.email;
    await fetchUserData(user.id);
}

// مراقبة أي تغيير لاحق (مثلاً لو انتهت الجلسة فجأة)
supabaseClient.auth.onAuthStateChange((event, session) => {
    if (!session) {
        window.location.href = '/';
    }
});

async function fetchUserData(userId) {
    const { data, error } = await supabaseClient
        .from('user_data')
        .select('username, phone, gender, age')
        .eq('id', userId)
        .single();

    if (data) {
        userExtraDataSpan.innerHTML = `
            الاسم: ${data.username} <br>
            الهاتف: <span dir="ltr">${data.phone}</span> <br>
            النوع: ${data.gender} <br>
            العمر: ${data.age}
        `;
    } else if (error) {
        userExtraDataSpan.textContent = 'تعذر جلب البيانات المرتبطة';
    }
}

async function logout() {
    await supabaseClient.auth.signOut();
    window.location.href = '/';
}

checkSession();